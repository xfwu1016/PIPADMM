#' @title PIPADMM
#' @description Partition-Insensitive Parallel ADMM Algorithm
#' @param X Matrix of predictors, of dimension (n*p); each row is an observation
#' @param y Response variable
#' @param loss A character string specifying the loss function to use. Available options are least squares loss (LS), asymmetric least squares loss (ALS), Huber loss (Huber), quantile loss (Quantile), smooth quantile loss 1 (SQ1) and smooth quantile loss 2 (SQ2)
#' @param penalty A character string specifying the penalty to use. Available options are Cnet, Enet, Mnet and Snet
#' @param lambda1 The tuning parameter for the first penalty
#' @param lambda2 The tuning parameter for the second penalty
#' @param tau The quantile level τ. The value must be in (0,1)
#' @param maxit Maximum number of iterations allowed in the ADMM algorithm at fixed lambda values. If the algorithm does not converge, consider increasing maxit
#' @param ka The constants need to be given in Huber, SQ1 and SQ2
#' @param M Number of local machines
#' @returns \item{beta}{Regression coefficient}
#' @returns \item{K}{number of iterations}
#' @returns \item{time}{calculation time}
#' @export
#' @examples
#' #######Example 1(Penalized quantile regression) 
#' n <- 30000
#' p <- 1000
#' beta_true = rep(0, p)
#' beta_true[6] = beta_true[12] = beta_true[15] = beta_true[20] = 1
#' X <- matrix(rnorm(n*p),n,p) 
#' X[,1] = pnorm(X[,1])
#' tau=0.7
#' e = rnorm(n)
#' y = X[,6]+X[,12]+X[,15]+X[,20]+0.7*X[,1]*e
#' beta_true[1] = 0.7*qnorm(tau)
#' lambda1  =0.1*sqrt(log(p)/n)
#' lambda2  = 0.001*sqrt(log(p)/n)
#' tau=0.7
#' maxit=500
#' ###quantile loss
#' loss="Quan"
#' ###Cnet
#' lambda1  =1.2*sqrt(log(p)/n)
#' lambda2  = 0.001*sqrt(log(p)/n)
#' penalty="Cnet"
#' PIP=PIPADMM(X,y,loss,penalty,lambda1,lambda2,tau,maxit,ka=0,M=1)
#' PIP$beta[c(1,6,12,15,20)]
#' length(which(abs(PIP$beta)>10^-4))
#' PIP$K
#' PIP$time
#' ###Enet
#' lambda1  =1.2*sqrt(log(p)/n)
#' lambda2  = 0.001*sqrt(log(p)/n)
#' penalty="Enet"
#' PIP=PIPADMM(X,y,loss,penalty,lambda1,lambda2,tau,maxit,ka=0,M=1)
#' PIP$beta[c(1,6,12,15,20)]
#' length(which(abs(PIP$beta)>10^-4))
#' PIP$K
#' PIP$time
#' ###Mnet
#' lambda1  =2*sqrt(log(p)/n)
#' lambda2  = 0.001*sqrt(log(p)/n)
#' penalty="Mnet"
#' PIP=PIPADMM(X,y,loss,penalty,lambda1,lambda2,tau,maxit,ka=0,M=1)
#' PIP$beta[c(1,6,12,15,20)]
#' length(which(abs(PIP$beta)>10^-4))
#' PIP$K
#' PIP$time
#' ###Snet
#' lambda1  =2*sqrt(log(p)/n)
#' lambda2  = 0.001*sqrt(log(p)/n)
#' penalty="Snet"
#' PIP=PIPADMM(X,y,loss,penalty,lambda1,lambda2,tau,maxit,ka=0,M=1)
#' PIP$beta[c(1,6,12,15,20)]
#' length(which(abs(PIP$beta)>10^-4))
#' PIP$K
#' PIP$time
#' ######Example 2(Penalized huber regression)
#' n <- 10000
#' p <- 10000
#' beta_true <- c(4,3,2,-2,-2,-2,rep(0,p-6))
#' X <- matrix(rnorm(n*p),n,p) 
#' y <- X %*% beta_true + rnorm(n,0,1)
#' maxit=500
#' ###Huber
#' loss="Huber"
#' ###Cnet
#' lambda1  =1.2*sqrt(log(p)/n)
#' lambda2  = 0.001*sqrt(log(p)/n)
#' penalty="Cnet"
#' PIP=PIPADMM(X,y,loss,penalty,lambda1,lambda2,tau=0,maxit,ka=1,M=1)
#' PIP$beta[1:6]
#' length(which(abs(PIP$beta)>10^-4))
#' PIP$K
#' PIP$time
#' ###Enet
#' lambda1  =1.2*sqrt(log(p)/n)
#' lambda2  = 0.001*sqrt(log(p)/n)
#' penalty="Enet"
#' PIP=PIPADMM(X,y,loss,penalty,lambda1,lambda2,tau=0,maxit,ka=1,M=1)
#' PIP$beta[1:6]
#' length(which(abs(PIP$beta)>10^-4))
#' PIP$K
#' PIP$time
#' ###Mnet
#' lambda1  =1.2*sqrt(log(p)/n)
#' lambda2  = 0.001*sqrt(log(p)/n)
#' penalty="Mnet"
#' PIP=PIPADMM(X,y,loss,penalty,lambda1,lambda2,tau=0,maxit,ka=1,M=1)
#' PIP$beta[1:6]
#' length(which(abs(PIP$beta)>10^-4))
#' PIP$K
#' PIP$time
#' ###Snet
#' lambda1  =1.2*sqrt(log(p)/n)
#' lambda2  = 0.001*sqrt(log(p)/n)
#' penalty="Snet"
#' PIP=PIPADMM(X,y,loss,penalty,lambda1,lambda2,tau=0,maxit,ka=1,M=1)
#' PIP$beta[1:6]
#' length(which(abs(PIP$beta)>10^-4))
#' PIP$K
#' PIP$time
#' ######Example 3(Penalized smooth quantile  regression(SQ1))
#' n <- 5000
#' p <- 500
#' beta_true <- c(rep(3,5),rep(-1.5,5),rep(1,5),rep(2,5),rep(0,p-20))
#' X <- matrix(rnorm(n*p),n,p) 
#' y <- X %*% beta_true + rnorm(n,0,1)
#' maxit=500
#' ###SQ1
#' loss="SQ1"
#' ###Cnet
#' lambda1  =0.5*sqrt(log(p)/n)
#' lambda2  = 0.001*sqrt(log(p)/n)
#' penalty="Cnet"
#' PIP=PIPADMM(X,y,loss,penalty,lambda1,lambda2,tau=0.5,maxit,ka=1,M=1)
#' PIP$beta[1:20]
#' length(which(abs(PIP$beta)>10^-4))
#' PIP$K
#' PIP$time
#' ###Enet
#' lambda1  =0.7*sqrt(log(p)/n)
#' lambda2  = 0.001*sqrt(log(p)/n)
#' penalty="Enet"
#' PIP=PIPADMM(X,y,loss,penalty,lambda1,lambda2,tau=0.5,maxit,ka=1,M=1)
#' PIP$beta[1:20]
#' length(which(abs(PIP$beta)>10^-4))
#' PIP$K
#' PIP$time
#' ###Mnet
#' lambda1  =0.9*sqrt(log(p)/n)
#' lambda2  = 0.001*sqrt(log(p)/n)
#' penalty="Mnet"
#' PIP=PIPADMM(X,y,loss,penalty,lambda1,lambda2,tau=0.5,maxit,ka=1,M=1)
#' PIP$beta[1:20]
#' length(which(abs(PIP$beta)>10^-4))
#' PIP$K
#' PIP$time
#' ###Snet
#' lambda1  =0.8*sqrt(log(p)/n)
#' lambda2  = 0.001*sqrt(log(p)/n)
#' penalty="Snet"
#' PIP=PIPADMM(X,y,loss,penalty,lambda1,lambda2,tau=0.5,maxit,ka=1,M=1)
#' PIP$beta[1:20]
#' length(which(abs(PIP$beta)>10^-4))
#' PIP$K
#' PIP$time
#' ######Example 4(Penalized smooth quantile  regression(SQ2))
#' n <- 1000
#' p <- 5000
#' beta_true <- c(rep(3,5),rep(-1.5,5),rep(1,5),rep(2,5),rep(0,p-20))
#' X <- matrix(rnorm(n*p),n,p) 
#' y <- X %*% beta_true + rnorm(n,0,1)
#' maxit=500
#' ###SQ2
#' loss="SQ2"
#' ###Cnet
#' lambda1  =0.6*sqrt(log(p)/n)
#' lambda2  = 0.001*sqrt(log(p)/n)
#' penalty="Cnet"
#' PIP=PIPADMM(X,y,loss,penalty,lambda1,lambda2,tau=0.5,maxit,ka=1,M=1)
#' PIP$beta[1:20]
#' length(which(abs(PIP$beta)>10^-4))
#' PIP$K
#' PIP$time
#' ###Enet
#' lambda1  =0.6*sqrt(log(p)/n)
#' lambda2  = 0.001*sqrt(log(p)/n)
#' penalty="Enet"
#' PIP=PIPADMM(X,y,loss,penalty,lambda1,lambda2,tau=0.5,maxit,ka=1,M=1)
#' PIP$beta[1:20]
#' length(which(abs(PIP$beta)>10^-4))
#' PIP$K
#' PIP$time
#' ###Mnet
#' lambda1  =0.6*sqrt(log(p)/n)
#' lambda2  = 0.001*sqrt(log(p)/n)
#' penalty="Mnet"
#' PIP=PIPADMM(X,y,loss,penalty,lambda1,lambda2,tau=0,maxit,ka=1,M=1)
#' PIP$beta[1:20]
#' length(which(abs(PIP$beta)>10^-4))
#' PIP$K
#' PIP$time
#' ###Snet
#' lambda1  =0.6*sqrt(log(p)/n)
#' lambda2  = 0.001*sqrt(log(p)/n)
#' penalty="Snet"
#' PIP=PIPADMM(X,y,loss,penalty,lambda1,lambda2,tau=0,maxit,ka=1,M=1)
#' PIP$beta[1:20]
#' length(which(abs(PIP$beta)>10^-4))
#' PIP$K
#' PIP$time
PIPADMM<-function(X,y,loss,penalty,lambda1,lambda2, tau,maxit, ka,M)
{
  if(loss=="LS"){L=LS}else if(loss=="ALS"){L=ALS}else if(loss=="Quan"){
    L=Quan}else if(loss=="SQ1"){L=SQ1}else if(loss=="Huber"){L=Huber}else{L=SQ2}  
  if(penalty=="Enet"){Pena=Enet}else if(penalty=="Snet"){Pena=Snet}else if(penalty=="Mnet"){Pena=Mnet}else{
    Pena=Cnet}
  p=ncol(X)
  n=nrow(X)
  group <- list()
  for (aa in 1:M) {
    group[[aa]] <- (1:n)[(n/M*(aa-1)+1) : (n/M*aa)]
  }
  
  ##
  ite=maxit
  beta_m=matrix(0,p,ite+1)
  r_m=matrix(0,n,ite+1)
  d_m=matrix(0,n,ite+1)
  ##
  begint <- proc.time()
  k=0
  if(n>p){mu=1/n}else{mu=1/p}#1/n#p>n 10^-5
  eta=pite2(X,x=rep(1,ncol(X)),ite=1000)[1]
  eta= mu*eta
  time_m=matrix(0,M,ite+1)
  repeat{
    XX_k = 0
    for (i in 1:M) {
      XX_k = XX_k +  t(X[group[[i]],])%*%(X[group[[i]],]%*%beta_m[,k+1] + r_m[group[[i]],k+1] - y[group[[i]]] - d_m[group[[i]],k+1]/mu) 
    }
    cc = beta_m[,k+1] -mu/eta*(XX_k)
    beta_m[,k+2] = Pena(lambda1,lambda2,eta,cc)
    for (i in 1:M) {
      begin <- proc.time()
      rr = y[group[[i]]] + d_m[group[[i]],k+1]/mu - X[group[[i]],]%*%beta_m[,k+2]
      r_m[group[[i]],k+2] = L(tau,n,mu,ka,rr)     
      d_m[group[[i]],k+2] = d_m[group[[i]],k+1] - mu*(r_m[group[[i]],k+2] + X[group[[i]],]%*%beta_m[,k+2] - y[group[[i]]])
      end <- proc.time()
      time_m[i,k]=(end-begin)[3]
    }
    k = k + 1
    Perror=sqrt(sum((beta_m[,k+1]-beta_m[,k])^2))/max(1,sqrt(sum(beta_m[,k]^2)))
    if((Perror<10^-3)|(k>ite-1)){break}
  }
  endt <- proc.time()
  Tol = endt-begint
  maxtime=0
  for (j in 1:ite) {maxtime = maxtime+max(time_m[,j])}
  result=list(beta=beta_m[,k],K=k,time= Tol[3] - sum(time_m)+maxtime)
  return(result)
}