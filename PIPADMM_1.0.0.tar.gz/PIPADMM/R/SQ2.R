#' @title Smooth quantile loss 2
#' @description The proximal operator of smooth quantile loss 2
#' @param tau The quantile level τ. The value must be in (0,1).
#' @param n The sample size
#' @param mu The augmented Lagrange constant
#' @param ka The constants need to be given in Huber, SQ1 and SQ2
#' @param rr The constant vectors in the proximal operators
#' @return The solution for the proximal operators of the loss
#' @export
SQ2=function(tau,n,mu,ka,rr){
  xu=rep(0,length(rr))
  for(i in 1:length(rr)){
    if(rr[i]>=tau*ka+tau/(n*mu)){xu[i]=rr[i] - tau/(n*mu)}else if(rr[i]<(tau-1)*(ka+1/(n*mu))){
      xu[i]=rr[i] - (tau-1)/(n*mu)}else{xu[i]=n*ka*mu*rr[i]/(n*ka*mu+1)}
  }
  return(xu)
}