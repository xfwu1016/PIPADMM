#' @title MCP and ridge
#' @description The proximal operator of Mnet (MCP and ridge)
#' @param lambda1 The tuning parameter for the first penalty
#' @param lambda2 The tuning parameter for the second penalty
#' @param eta The constant for the proximal operators of the penalty
#' @param bb The constant vectors in the proximal operators
#' @return The solution for the proximal operators of the penalty
#' @export
Mnet<-function(lambda1,lambda2,eta,bb){
  a=3
  beta_k=rep(0, length(bb))
  for (i in 1:length(bb)) {
    if(abs(bb[i])<lambda1*a*(eta+lambda2)/eta){beta_k[i]=sign(bb[i])*
      max((a*eta*abs(bb[i])-
             a*lambda1)/(a*(eta+lambda2)-1),0)}else{
               beta_k[i] = eta*bb[i]/(eta+lambda2)}
  }
  return(beta_k)
}