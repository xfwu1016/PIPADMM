#' @title Smooth quantile loss 1
#' @description The proximal operator of smooth quantile loss 1
#' @param tau The quantile level τ. The value must be in (0,1).
#' @param n The sample size
#' @param mu The augmented Lagrange constant
#' @param ka The constants need to be given in Huber, SQ1 and SQ2
#' @param rr The constant vectors in the proximal operators
#' @return The solution for the proximal operators of the loss
#' @export
SQ1=function(tau,n,mu,ka,rr){
  xu=rep(0,length(rr))
  for(i in 1:length(rr)){
    if(rr[i]>=ka+tau/(n*mu)){xu[i]=rr[i] - tau/(n*mu)}else if((rr[i]>=0)&(rr[i]<ka+tau/(n*mu))){
      xu[i]=n*ka*mu*rr[i]/(n*ka*mu+tau)}else if((rr[i]>=-ka+(tau-1)/(n*mu))&(rr[i]<0)){
        xu[i]=n*ka*mu*rr[i]/(n*ka*mu+1-tau)}else{xu[i]=rr[i] - (tau-1)/(n*mu)}
  }
  return(xu)
}