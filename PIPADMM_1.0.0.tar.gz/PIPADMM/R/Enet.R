#' @title Elastic net
#' @description The proximal operator of elastic net (L1 + ridge)
#' @param lambda1 The tuning parameter for the first penalty
#' @param lambda2 The tuning parameter for the second penalty
#' @param eta The constant for the proximal operators of the penalty
#' @param bb The constant vectors in the proximal operators
#' @return The solution for the proximal operators of the penalty
#' @export
Enet<-function(lambda1,lambda2,eta,bb){
  beta_k=rep(0, length(bb))
  for (i in 1:length(bb)) {
    beta_k[i]=sign(bb[i])*max(0,eta/(eta+lambda2)*abs(bb[i])-lambda1/(lambda2+eta))
    
  }
  return(beta_k)
}
