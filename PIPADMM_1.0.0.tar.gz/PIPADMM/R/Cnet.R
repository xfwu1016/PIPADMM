#' @title Capped-L1 and ridge
#' @description The proximal operator of Cnet (capped-L1 and ridge)
#' @param lambda1 The tuning parameter for the first penalty
#' @param lambda2 The tuning parameter for the second penalty
#' @param eta The constant for the proximal operators of the penalty
#' @param bb The constant vectors in the proximal operators
#' @return The solution for the proximal operators of the penalty
#' @export
Cnet<-function(lambda1,lambda2,eta,bb){
  a=3
  beta_k=rep(0, length(bb))
  for (i in 1:length(bb)) {
    if(abs(bb[i])<a*(eta+lambda2)/eta){beta_k[i]=sign(bb[i])*
      max((eta*abs(bb[i])-lambda1)/(eta+lambda2),0)}else{
        beta_k[i] = eta*bb[i]/(eta+lambda2)}
  }
  return(beta_k)
}

